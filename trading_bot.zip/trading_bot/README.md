# Trading Bot — Binance Futures Testnet (USDT-M)

A small, structured Python CLI application that places **MARKET**, **LIMIT**,
and (bonus) **STOP-LIMIT** orders on the Binance Futures Testnet, with input
validation, structured logging, and clean error handling.

Built for the Python Developer Intern application task (Primetrade.ai).

## Project Structure

```
trading_bot/
├── bot/
│   ├── __init__.py
│   ├── client.py          # Binance API client wrapper (Futures Testnet)
│   ├── orders.py          # Order building + placement logic
│   ├── validators.py      # CLI input validation
│   └── logging_config.py  # Rotating file + console logging setup
├── cli.py                 # CLI entry point (argparse)
├── logs/                  # Log files (sample + generated)
├── requirements.txt
├── .env.example
└── README.md
```

Separation of concerns:
- **`client.py`** — only talks to Binance (the "API layer").
- **`orders.py`** — builds order payloads and prints request/response summaries.
- **`validators.py`** — pure input validation, no side effects, easy to unit test.
- **`cli.py`** — wires everything together, the only file that touches `argparse`.

## Setup

### 1. Get Binance Futures Testnet API keys
1. Go to https://testnet.binancefuture.com and log in with GitHub.
2. Once logged in, generate an API Key + Secret from the site.
3. (No real funds are involved — this is a sandbox with fake USDT.)

### 2. Clone and install
```bash
git clone <your-repo-url>
cd trading_bot
python -m venv .venv
source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

### 3. Configure credentials
```bash
cp .env.example .env
# then edit .env and paste your testnet API key/secret
```

## How to Run

**Market order (BUY):**
```bash
python cli.py --symbol BTCUSDT --side BUY --type MARKET --quantity 0.01
```

**Limit order (SELL):**
```bash
python cli.py --symbol BTCUSDT --side SELL --type LIMIT --quantity 0.01 --price 65000
```

**Bonus — Stop-Limit order (BUY):**
```bash
python cli.py --symbol BTCUSDT --side BUY --type STOP --quantity 0.01 \
  --price 61000 --stop-price 60900
```

Each run prints:
- an order **request summary** (what's being sent)
- the order **response** (`orderId`, `status`, `executedQty`, `avgPrice`)
- a clear success (`✅`) or failure (`❌`) message

All API requests, responses, and errors are also written to `logs/trading_bot.log`
(rotating, 3 backups, 2 MB each) — see `logs/sample_market_order.log` and
`logs/sample_limit_order.log` for the exact format this produces.

## Input Validation

`bot/validators.py` checks, before any network call is made:
- `symbol` — must look like a valid trading pair (e.g. `BTCUSDT`)
- `side` — must be `BUY` or `SELL`
- `type` — must be `MARKET`, `LIMIT`, or `STOP`
- `quantity` — must be a positive number
- `price` — required (and positive) for `LIMIT` / `STOP`
- `stop-price` — required (and positive) for `STOP`

Invalid input fails fast with a clear message and never reaches the Binance API.

## Error Handling

`bot/client.py` distinguishes between:
- **`BinanceOrderException`** — order rejected (e.g. bad quantity precision)
- **`BinanceAPIException`** — API-level error (e.g. bad signature, rate limit)
- **`RequestException`** — network/connectivity failure
- any other unexpected exception

All are logged with context and re-raised so `cli.py` can exit with a
non-zero status and a readable error message.

## Bonus Feature Implemented

**Third order type — Stop-Limit (`--type STOP`)**: places a `STOP` order with
both a trigger `stopPrice` and a limit `price`, reusing the same validation,
logging, and client code path as MARKET/LIMIT.

## Assumptions

- Binance Futures Testnet (USDT-M) is used exclusively — the client hard-codes
  `https://testnet.binancefuture.com/fapi` and initializes `python-binance`
  with `testnet=True`, so it will never touch the live/production API.
- Orders use default settings appropriate for a testnet demo: `GTC`
  (Good-Til-Canceled) for LIMIT/STOP orders, and no leverage/margin-mode
  changes are made — it's assumed the testnet account is already set up with
  a reasonable default leverage on the traded symbol.
- The CLI takes one order per invocation (simplest, most testable UX); it can
  be scripted/looped for multiple orders.
- The two sample log files in `logs/` (`sample_market_order.log`,
  `sample_limit_order.log`) illustrate the exact log format the bot produces.
  Run the two commands above with your own testnet keys to generate live
  ones in `logs/trading_bot.log`.

## Requirements

```
python-binance==1.0.19
python-dotenv==1.0.1
requests==2.32.3
```
