#!/usr/bin/env python3
"""
cli.py
------
CLI entry point for the simplified Binance Futures Testnet trading bot.

Usage examples:
    python cli.py --symbol BTCUSDT --side BUY --type MARKET --quantity 0.01
    python cli.py --symbol BTCUSDT --side SELL --type LIMIT --quantity 0.01 --price 60000
    python cli.py --symbol BTCUSDT --side BUY --type STOP --quantity 0.01 \
                   --price 61000 --stop-price 60900
"""
import argparse
import logging
import os
import sys

from dotenv import load_dotenv

from bot.logging_config import setup_logging
from bot.client import BinanceFuturesClient
from bot.orders import OrderService
from bot import validators
from bot.validators import ValidationError


def parse_args():
    parser = argparse.ArgumentParser(
        prog="trading_bot",
        description="Simplified trading bot for Binance Futures Testnet (USDT-M).",
    )
    parser.add_argument("--symbol", required=True, help="Trading pair, e.g. BTCUSDT")
    parser.add_argument(
        "--side", required=True,
        choices=["BUY", "SELL", "buy", "sell"],
    )
    parser.add_argument(
        "--type", required=True, dest="order_type",
        choices=["MARKET", "LIMIT", "STOP", "market", "limit", "stop"],
        help="Order type. STOP is a bonus stop-limit order.",
    )
    parser.add_argument("--quantity", required=True, help="Order quantity")
    parser.add_argument("--price", required=False, help="Required for LIMIT/STOP orders")
    parser.add_argument(
        "--stop-price", required=False, dest="stop_price",
        help="Required for STOP orders (trigger price)",
    )
    return parser.parse_args()


def main():
    load_dotenv()
    logger = setup_logging(level=logging.INFO)
    args = parse_args()

    # ---- Validate input -------------------------------------------------
    try:
        symbol = validators.validate_symbol(args.symbol)
        side = validators.validate_side(args.side)
        order_type = validators.validate_order_type(args.order_type)
        quantity = validators.validate_quantity(args.quantity)
        price = validators.validate_price(args.price, order_type)
        stop_price = validators.validate_stop_price(args.stop_price, order_type)
    except ValidationError as e:
        logger.error(f"Input validation failed: {e}")
        print(f"\u274c Invalid input: {e}")
        sys.exit(1)

    # ---- Load credentials -------------------------------------------------
    api_key = os.getenv("BINANCE_API_KEY")
    api_secret = os.getenv("BINANCE_API_SECRET")

    if not api_key or not api_secret:
        logger.error("Missing BINANCE_API_KEY / BINANCE_API_SECRET in environment.")
        print("\u274c Set BINANCE_API_KEY and BINANCE_API_SECRET (copy .env.example to .env).")
        sys.exit(1)

    # ---- Place order --------------------------------------------------
    try:
        client = BinanceFuturesClient(api_key, api_secret)
        service = OrderService(client)
        service.place_order(symbol, side, order_type, quantity, price, stop_price)
    except Exception as e:
        logger.error(f"Order placement failed: {e}")
        print(f"\u274c Order placement failed: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
