"""
validators.py
--------------
Validation of CLI input before anything is sent to Binance.
Keeping this separate from cli.py and client.py makes it easy to unit
test and to reuse for the bonus STOP (stop-limit) order type.
"""
import re

VALID_SIDES = {"BUY", "SELL"}
VALID_TYPES = {"MARKET", "LIMIT", "STOP"}  # STOP = bonus stop-limit order
SYMBOL_RE = re.compile(r"^[A-Z0-9]{5,15}$")


class ValidationError(Exception):
    """Raised when user-supplied CLI input fails validation."""


def validate_symbol(symbol: str) -> str:
    symbol = (symbol or "").strip().upper()
    if not SYMBOL_RE.match(symbol):
        raise ValidationError(
            f"Invalid symbol '{symbol}'. Expected format like 'BTCUSDT'."
        )
    return symbol


def validate_side(side: str) -> str:
    side = (side or "").strip().upper()
    if side not in VALID_SIDES:
        raise ValidationError(f"Invalid side '{side}'. Must be BUY or SELL.")
    return side


def validate_order_type(order_type: str) -> str:
    order_type = (order_type or "").strip().upper()
    if order_type not in VALID_TYPES:
        raise ValidationError(
            f"Invalid order type '{order_type}'. Must be one of {sorted(VALID_TYPES)}."
        )
    return order_type


def validate_quantity(quantity) -> float:
    try:
        quantity = float(quantity)
    except (TypeError, ValueError):
        raise ValidationError(f"Quantity must be a number, got '{quantity}'.")
    if quantity <= 0:
        raise ValidationError("Quantity must be greater than 0.")
    return quantity


def validate_price(price, order_type: str):
    """Price is required for LIMIT and STOP orders, forbidden/ignored for MARKET."""
    if order_type in ("LIMIT", "STOP"):
        if price is None:
            raise ValidationError(f"--price is required for {order_type} orders.")
        try:
            price = float(price)
        except (TypeError, ValueError):
            raise ValidationError(f"Price must be a number, got '{price}'.")
        if price <= 0:
            raise ValidationError("Price must be greater than 0.")
        return price
    return None


def validate_stop_price(stop_price, order_type: str):
    """Stop price is required only for the bonus STOP order type."""
    if order_type == "STOP":
        if stop_price is None:
            raise ValidationError("--stop-price is required for STOP orders.")
        try:
            stop_price = float(stop_price)
        except (TypeError, ValueError):
            raise ValidationError(f"Stop price must be a number, got '{stop_price}'.")
        if stop_price <= 0:
            raise ValidationError("Stop price must be greater than 0.")
        return stop_price
    return None
