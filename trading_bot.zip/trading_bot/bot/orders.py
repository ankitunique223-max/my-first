"""
orders.py
---------
Turns validated CLI input into a Binance order payload, sends it via
BinanceFuturesClient, and prints a clean summary of the request and
response.
"""
import logging

from bot.client import BinanceFuturesClient

logger = logging.getLogger("trading_bot")


class OrderService:
    def __init__(self, client: BinanceFuturesClient):
        self.client = client

    @staticmethod
    def build_order_params(symbol, side, order_type, quantity, price=None, stop_price=None) -> dict:
        """Translate our simplified order_type into Binance API params."""
        params = {
            "symbol": symbol,
            "side": side,
            "type": "STOP" if order_type == "STOP" else order_type,
            "quantity": quantity,
        }

        if order_type == "LIMIT":
            params["timeInForce"] = "GTC"
            params["price"] = price

        if order_type == "STOP":
            # Bonus order type: stop-limit
            params["price"] = price
            params["stopPrice"] = stop_price
            params["timeInForce"] = "GTC"

        return params

    def place_order(self, symbol, side, order_type, quantity, price=None, stop_price=None) -> dict:
        params = self.build_order_params(symbol, side, order_type, quantity, price, stop_price)

        print("\n--- Order Request Summary ---")
        for k, v in params.items():
            print(f"{k:12}: {v}")
        print("------------------------------")

        try:
            response = self.client.place_order(**params)
        except Exception as e:
            print(f"\n\u274c Order FAILED: {e}\n")
            raise

        print("\n--- Order Response ---")
        print(f"orderId     : {response.get('orderId')}")
        print(f"status      : {response.get('status')}")
        print(f"executedQty : {response.get('executedQty')}")
        print(f"avgPrice    : {response.get('avgPrice', 'N/A')}")
        print("----------------------")
        print("\u2705 Order placed successfully.\n")

        return response
