"""
client.py
---------
Thin wrapper around python-binance's Client, pinned to the Binance
Futures Testnet (USDT-M). Keeping this in its own module isolates all
network/API concerns from the CLI and order-building logic.
"""
import logging

from binance.client import Client
from binance.exceptions import BinanceAPIException, BinanceOrderException
from requests.exceptions import RequestException

logger = logging.getLogger("trading_bot")

FUTURES_TESTNET_BASE_URL = "https://testnet.binancefuture.com/fapi"


class BinanceFuturesClient:
    """Wraps python-binance, forced onto the Futures Testnet endpoints."""

    def __init__(self, api_key: str, api_secret: str):
        if not api_key or not api_secret:
            raise ValueError("API key and secret must both be provided.")

        # testnet=True switches the underlying spot endpoints; for futures
        # we also explicitly override FUTURES_URL to be safe across
        # python-binance versions.
        self.client = Client(api_key, api_secret, testnet=True)
        self.client.FUTURES_URL = FUTURES_TESTNET_BASE_URL
        logger.info("Binance Futures Testnet client initialized.")

    def get_symbol_info(self, symbol: str):
        """Fetch exchange info for a symbol (used for pre-flight checks)."""
        try:
            info = self.client.futures_exchange_info()
            for s in info.get("symbols", []):
                if s["symbol"] == symbol:
                    return s
            return None
        except (BinanceAPIException, RequestException) as e:
            logger.error(f"Failed to fetch symbol info for {symbol}: {e}")
            raise

    def place_order(self, **kwargs):
        """
        Place an order via futures_create_order.
        kwargs use Binance's own param names (symbol, side, type,
        quantity, price, timeInForce, stopPrice, ...).
        """
        logger.info(f"Sending order request: {kwargs}")
        try:
            response = self.client.futures_create_order(**kwargs)
            logger.info(f"Order response received: {response}")
            return response
        except BinanceOrderException as e:
            logger.error(f"Order rejected by Binance: {e}")
            raise
        except BinanceAPIException as e:
            logger.error(f"Binance API error (code={e.code}): {e.message}")
            raise
        except RequestException as e:
            logger.error(f"Network error while contacting Binance: {e}")
            raise
        except Exception as e:
            logger.error(f"Unexpected error while placing order: {e}")
            raise
